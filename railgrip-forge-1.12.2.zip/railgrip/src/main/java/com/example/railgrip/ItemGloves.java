package com.example.railgrip;

import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;

/** Перчатки зацепера: ПКМ — надеть на руки (+30% к силе хвата). */
public class ItemGloves extends Item {
    public ItemGloves() {
        setRegistryName(RailGrip.MODID, "grip_gloves");
        setUnlocalizedName(RailGrip.MODID + ".grip_gloves");
        setCreativeTab(CreativeTabs.TRANSPORTATION);
        setMaxStackSize(1);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            if (GloveData.isEquipped(player)) {
                player.sendStatusMessage(new TextComponentTranslation("msg.railgrip.already"), true);
                return new ActionResult<ItemStack>(EnumActionResult.FAIL, stack);
            }
            GloveData.setEquipped(player, true);
            stack.shrink(1);
            player.sendStatusMessage(new TextComponentTranslation("msg.railgrip.equipped"), true);
        }
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.format("tooltip.railgrip.gloves1"));
        tooltip.add(I18n.format("tooltip.railgrip.gloves2"));
    }
}
