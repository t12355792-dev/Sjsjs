package com.example.railgrip;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = RailGrip.MODID)
public class ModItems {
    public static final Item GLOVES = new ItemGloves();
    public static final Item SPEEDOMETER = new ItemSpeedometer();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(GLOVES, SPEEDOMETER);
    }
}
