package com.example.railgrip;

public class CommonProxy {
    public void preInit() {}
    public void init() {}
    public void postInit() {}
    public void handleGlove(long most, long least, boolean on) {}
}
