package com.example.railgrip;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.network.NetworkRegistry;

/** Состояние «перчатки надеты» хранится в постоянных данных игрока и синхронизируется с клиентами. */
public final class GloveData {
    private static final String KEY = "railgrip_gloves";

    private GloveData() {}

    private static NBTTagCompound persisted(EntityPlayer p) {
        NBTTagCompound data = p.getEntityData();
        if (!data.hasKey(EntityPlayer.PERSISTED_NBT_TAG)) {
            data.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        }
        return data.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
    }

    public static boolean isEquipped(EntityPlayer p) {
        return persisted(p).getBoolean(KEY);
    }

    public static void setEquipped(EntityPlayer p, boolean value) {
        persisted(p).setBoolean(KEY, value);
        sync(p);
    }

    /** Отправляет состояние самому игроку и всем, кто рядом. */
    public static void sync(EntityPlayer p) {
        if (!(p instanceof EntityPlayerMP)) return;
        Net.MsgGlove msg = new Net.MsgGlove(p.getUniqueID().getMostSignificantBits(),
                p.getUniqueID().getLeastSignificantBits(), isEquipped(p));
        Net.CH.sendTo(msg, (EntityPlayerMP) p);
        Net.CH.sendToAllAround(msg, new NetworkRegistry.TargetPoint(p.dimension, p.posX, p.posY, p.posZ, 128));
    }

    public static void sendTo(EntityPlayer target, EntityPlayerMP viewer) {
        Net.CH.sendTo(new Net.MsgGlove(target.getUniqueID().getMostSignificantBits(),
                target.getUniqueID().getLeastSignificantBits(), isEquipped(target)), viewer);
    }
}
