package com.example.railgrip;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = RailGrip.MODID)
public class ClientModels {
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ModItems.GLOVES, 0,
                new ModelResourceLocation(ModItems.GLOVES.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.SPEEDOMETER, 0,
                new ModelResourceLocation(ModItems.SPEEDOMETER.getRegistryName(), "inventory"));
    }
}
